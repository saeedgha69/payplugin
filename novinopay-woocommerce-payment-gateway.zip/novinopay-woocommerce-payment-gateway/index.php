<?php
/*
Plugin Name: نوینو پرداخت | ووکامرس
Version: 1.4.3
Author: NovinoPay
Description:  افزونه پرداخت آنلاین نوینو پرداخت برای فروشگاه ساز ووکامرس
Plugin URI: https://novinopay.com
*/
include_once("class-wc-gateway-novinopay.php");
